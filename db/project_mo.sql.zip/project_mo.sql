-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2019 at 05:02 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_mo`
--
CREATE DATABASE IF NOT EXISTS `project_mo` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `project_mo`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_booking`
--

CREATE TABLE `admin_booking` (
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `booking_id` int(11) NOT NULL,
  `stu_id` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin_booking`
--

INSERT INTO `admin_booking` (`name`, `booking_id`, `stu_id`) VALUES
('อภิสิทธิ์', 28, '5555555555'),
('อภิสิทธิ์', 29, '5721600080'),
('อภิสิทธิ์', 30, '5721600081'),
('ssssss', 31, '5721600082'),
('อภิสิทธิ์', 32, '5721600083'),
('อภิสิทธิ์', 33, '5721600083'),
('อภิสิทธิ์', 34, '5721600083'),
('อภิสิทธิ์', 35, '5721600081'),
('อภิสิทธิ์', 36, '5721600081'),
('อภิสิทธิ์', 37, '5721600081'),
('อภิสิทธิ์', 38, '5721600081'),
('อภิสิทธิ์', 39, '5721600083'),
('อภิสิทธิ์', 40, '5721600080'),
('อภิสิทธิ์', 41, '5721600080'),
('อภิสิทธิ์', 42, '6666666666'),
('อภิสิทธิ์', 43, '6666666666'),
('อภิสิทธิ์', 44, '6666666666'),
('อภิสิทธิ์', 45, '6666666666'),
('อภิสิทธิ์', 46, '6666666666');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `room_id` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `booking_day` date NOT NULL,
  `booking_in` time NOT NULL,
  `booking_out` time NOT NULL,
  `booking_date` datetime NOT NULL,
  `booking_status` int(11) NOT NULL,
  `user_name` varchar(11) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `room_id`, `booking_day`, `booking_in`, `booking_out`, `booking_date`, `booking_status`, `user_name`) VALUES
(25, '1', '2019-12-24', '12:00:00', '15:00:00', '2019-12-24 11:30:40', 2, '5721600080'),
(27, '1', '2019-12-25', '12:00:00', '15:00:00', '2019-12-24 11:36:55', 3, '5721600080'),
(28, '1', '2019-12-25', '15:00:00', '18:00:00', '2019-12-24 15:37:39', 3, 'adminadmin'),
(29, '1', '2019-12-26', '09:00:00', '12:00:00', '2019-12-25 13:44:20', 3, 'adminadmin'),
(30, '1', '2019-12-25', '12:00:00', '15:00:00', '2019-12-25 14:15:29', 3, 'adminadmin'),
(31, '1', '2019-12-26', '12:00:00', '15:00:00', '2019-12-25 14:19:27', 3, 'adminadmin'),
(32, '1', '2019-12-26', '12:00:00', '15:00:00', '2019-12-25 14:20:18', 3, 'adminadmin'),
(33, '1', '2019-12-26', '12:00:00', '15:00:00', '2019-12-25 14:29:43', 3, 'adminadmin'),
(34, '1', '2019-12-26', '12:00:00', '15:00:00', '2019-12-25 14:32:29', 3, 'adminadmin'),
(35, '1', '2019-12-25', '12:00:00', '15:00:00', '2019-12-25 14:34:10', 3, 'adminadmin'),
(36, '1', '2019-12-25', '12:00:00', '15:00:00', '2019-12-25 14:34:47', 3, 'adminadmin'),
(37, '1', '2019-12-25', '12:00:00', '15:00:00', '2019-12-25 14:37:03', 3, 'adminadmin'),
(38, '1', '2019-12-25', '12:00:00', '15:00:00', '2019-12-25 14:48:44', 3, 'adminadmin'),
(39, '1', '2019-12-26', '12:00:00', '15:00:00', '2019-12-25 14:49:42', 3, 'adminadmin'),
(40, '1', '2019-12-25', '18:00:00', '21:00:00', '2019-12-25 20:38:41', 2, 'adminadmin'),
(41, '2', '2019-12-25', '18:00:00', '21:00:00', '2019-12-25 20:38:52', 3, 'adminadmin'),
(42, '2', '2019-12-25', '18:00:00', '22:00:00', '2019-12-25 21:29:35', 3, 'adminadmin'),
(43, '3', '2019-12-25', '18:00:00', '22:00:00', '2019-12-25 21:29:44', 3, 'adminadmin'),
(44, '4', '2019-12-25', '18:00:00', '22:00:00', '2019-12-25 21:31:47', 3, 'adminadmin'),
(45, '1', '2019-12-26', '12:00:00', '15:00:00', '2019-12-25 21:38:16', 3, 'adminadmin'),
(46, '1', '2019-12-26', '15:00:00', '18:00:00', '2019-12-25 21:38:21', 1, 'adminadmin'),
(47, '1', '2019-12-28', '19:20:00', '12:00:00', '2019-12-26 15:12:53', 3, '5721600080');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `question_id` int(11) NOT NULL,
  `question_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`question_id`, `question_name`) VALUES
(1, 'หมาของคุณชื่ออะไร'),
(2, 'เเมวของคุณชื่ออะไร'),
(3, 'สีที่คุณชอบ'),
(4, 'ดอกไม้ที่คุณชอบ'),
(5, 'คนที่คุณรักที่สุด');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int(11) NOT NULL,
  `room_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `room_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_name`, `room_status`) VALUES
(1, 'ห้องที่ 1', 0),
(2, 'ห้องที่ 2', 0),
(3, 'ห้องที่ 3', 0),
(4, 'ห้องที่ 4', 0);

-- --------------------------------------------------------

--
-- Table structure for table `time`
--

CREATE TABLE `time` (
  `time_id` int(11) NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  `time_status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `time`
--

INSERT INTO `time` (`time_id`, `time_in`, `time_out`, `time_status`) VALUES
(1, '09:00:00', '12:00:00', '1'),
(2, '12:00:00', '15:00:00', '0'),
(3, '15:00:00', '18:00:00', '0'),
(4, '18:00:00', '21:00:00', '0'),
(5, '01:00:00', '04:00:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `question_id` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `answer` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_name`, `password`, `name`, `last_name`, `status`, `email`, `phone`, `question_id`, `answer`) VALUES
('5721600080', '123456789', 'เทสหห', 'หหหหหหหห', '0', 'mo145@hotmail.com', '0812767611', '1', 'ssss'),
('adminadmin', '123456789', 'เเอดมิน', '', '2', 'moadimin@gmail.com', '0844458652', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_booking`
--
ALTER TABLE `admin_booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `time`
--
ALTER TABLE `time`
  ADD PRIMARY KEY (`time_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `time`
--
ALTER TABLE `time`
  MODIFY `time_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
