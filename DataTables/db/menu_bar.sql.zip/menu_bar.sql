-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2019 at 09:51 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spb3`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu_bar`
--

DROP TABLE IF EXISTS `menu_bar`;
CREATE TABLE `menu_bar` (
  `menu_bar_id` int(11) NOT NULL,
  `menu_bar_name` varchar(50) NOT NULL,
  `menu_bar_link` varchar(200) NOT NULL,
  `menu_bar_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu_bar`
--

INSERT INTO `menu_bar` (`menu_bar_id`, `menu_bar_name`, `menu_bar_link`, `menu_bar_count`) VALUES
(1, 'ข้อมูลขั้นพื้นฐาน', '', 1),
(2, 'เว็บไซด์กลุ่มภายใน', '', 2),
(3, 'Smart Office', '', 3),
(4, 'คู่มือปฏิบัติงาน ', '', 4),
(5, 'เว็บไซด์โรงเรียน ', '', 5),
(6, 'การบริหารงบประมาณ (BMSPB3)', '', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu_bar`
--
ALTER TABLE `menu_bar`
  ADD PRIMARY KEY (`menu_bar_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu_bar`
--
ALTER TABLE `menu_bar`
  MODIFY `menu_bar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
