-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2019 at 09:51 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spb3`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu_bar_drop`
--

DROP TABLE IF EXISTS `menu_bar_drop`;
CREATE TABLE `menu_bar_drop` (
  `menu_bar_id` int(11) NOT NULL,
  `menu_bar_drop_id` int(11) NOT NULL,
  `menu_bar_name` varchar(50) NOT NULL,
  `menu_bar_link` varchar(300) NOT NULL,
  `menu_bar_count` int(11) NOT NULL,
  `menu_bar_way` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu_bar_drop`
--

INSERT INTO `menu_bar_drop` (`menu_bar_id`, `menu_bar_drop_id`, `menu_bar_name`, `menu_bar_link`, `menu_bar_count`, `menu_bar_way`) VALUES
(1, 1, 'ประวัติสำนักงาน', 'history_spb3.php', 1, 430),
(1, 2, 'โครงสร้างหน่วยงาน', 'agency_structure.php', 2, 220),
(1, 3, 'ข้อมูลผู้บริหาร', 'agency_structure_manager.php', 3, 220),
(1, 4, 'อำนาจหน้าที่', 'agency_structure_duty.php', 4, 220),
(1, 5, 'เเผนพัฒนาคุณภาพการศึกษา', 'banner2_detail_show.php?id=97', 5, 220),
(1, 6, 'วิสัยทัศน์ เเละพันธกิจ', 'agency_structure_vision.php', 6, 220),
(1, 7, 'ข้อมูลติดต่อ', 'agency_structure_contact.php', 7, 220),
(1, 8, 'กฎหมายที่เกี่ยวข้อง', 'banner2_detail.php?id=9', 8, 220),
(2, 9, 'กลุ่มอำนวยการ', 'https://amnuaykan.thai.ac/home/', 1, 220),
(2, 10, 'กลุ่มบริหารงานบุคคล', 'https://sites.google.com/view/grouppersonnel/%E0%B8%AB%E0%B8%99%E0%B8%B2%E0%B9%81%E0%B8%A3%E0%B8%81', 2, 220),
(2, 11, 'กลุ่มนโยบายเเละเเผน', 'https://planspb3.thai.ac/home/', 3, 220),
(2, 12, 'กลุ่มนิเทศ ติดตาม เเละประเมินผลการจัดการศึกษา', 'https://nitedspb3.thai.ac/home/', 4, 220),
(2, 13, 'กลุ่มส่งเสริมการจัดการศึกษา', 'https://supportspb3.thai.ac/home/', 5, 220),
(2, 14, 'กลุ่มบริหารงานการเงินฯ', 'https://sites.google.com/view/groupmoney/%E0%B8%AB%E0%B8%99%E0%B8%B2%E0%B9%81%E0%B8%A3%E0%B8%81', 6, 220),
(2, 15, 'กลุ่มพัฒนาบุคลากร', 'https://pathnadikhun.thai.ac/home/', 7, 220),
(2, 16, 'กลุ่มส่งเสริมการศึกษาทางไกลฯ', 'https://sites.google.com/view/groupdltv/%E0%B8%AB%E0%B8%99%E0%B8%B2%E0%B9%81%E0%B8%A3%E0%B8%81', 8, 220),
(2, 17, 'หน่วยตรวจสอบภายใน', 'https://sites.google.com/view/grouptest/%E0%B8%AB%E0%B8%99%E0%B8%B2%E0%B9%81%E0%B8%A3%E0%B8%81', 9, 220),
(2, 18, 'กลุ่มกฏหมายเเละคดี', 'https://sites.google.com/view/lowsspb3/%E0%B8%AB%E0%B8%99%E0%B8%B2%E0%B9%81%E0%B8%A3%E0%B8%81', 10, 220),
(3, 19, 'Smart Office', 'http://159.192.129.42/spb3/', 1, 430),
(3, 20, 'ระบบสลิปเงินเดือน', 'http://www.spb3.go.th/SalaryOnWeb/', 2, 220),
(3, 21, 'ระบบการจัดซื้อจัดจ้างภาครัฐ', 'http://www.gprocurement.go.th/wps/portal/egp/!ut/p/z1/hY4xC8IwFIR_S4eO5r1aqOIWMihCqC5a3yKtpGmhJiWNBv-9ATdRetvdfQcHBBWQqZ-9rn1vTT1Ef6HiKrPtMhMCZXnKC-SrgxTlcYcoMjjPARRr_COOcU9zyB5ID7b5vOGmydcayKlWOeXYw8W4836cNimmGEJg2lo9KHazzHcp_hp1dvJQfbMw3itcUPMKPEne7ih2FA!!/dz/d5/L2dBISEvZ0FBIS9nQSEh/?locale=th', 3, 220),
(3, 22, 'ระบบ DMC', 'https://portal.bopp-obec.info/obec61/auth/login', 4, 220),
(3, 23, 'ระบบ EMIS', 'http://data.bopp-obec.info/emis/', 5, 220),
(3, 24, 'ระบบ CCT (ปัจจัยพื้นฐานนักเรียนยากจน)', 'https://cct.thaieduforall.org/', 6, 220),
(3, 25, 'ระบบ Schoolmis', 'http://a7203.obec.expert/authen/login', 7, 220),
(3, 26, 'ระบบ O-NET', 'http://www.newonetresult.niets.or.th/ExamWeb/FrLogin.aspx?ReturnUrl=/ExamWeb/default.aspx', 8, 220),
(4, 27, 'กลุ่มอำนวยการ', 'manual.php?id=1', 1, 220),
(4, 28, 'กลุ่มบริหารงานบุคคล', 'manual.php?id=2', 2, 220),
(4, 29, 'กลุ่มนโยบายและแผน', 'manual.php?id=3', 3, 220),
(4, 30, 'กลุ่มนิเทศ ติดตาม และประเมินผลการจัดการศึกษา', 'manual.php?id=4', 4, 220),
(4, 31, 'กลุ่มส่งเสริมการจัดการศึกษา', 'manual.php?id=5', 5, 220),
(4, 32, 'กลุ่มบริหารงานการเงินฯ', 'manual.php?id=6', 6, 220),
(4, 33, 'กลุ่มพัฒนาครูเเละบุคคลากรทางการศึกษา', 'manual.php?id=7', 7, 220),
(4, 34, 'กลุ่มส่งเสริมการศึกษาทางไกลฯ', 'manual.php?id=8', 8, 220),
(4, 35, 'หน่วยตรวจสอบภายใน', 'manual.php?id=9', 9, 220),
(4, 36, 'กลุ่มกฏหมายเเละคดี', 'manual.php?id=10', 10, 220),
(5, 37, 'สหวิทยาเขตบ่อกรุ', 'http://159.192.129.43/sPb3/index.php/borkruwebsite', 1, 545),
(5, 38, 'สหวิทยาเขตบึงฉวาก', 'http://159.192.129.43/sPb3/index.php/bungchawakwebsite', 2, 545),
(5, 39, 'สหวิทยาเขตพระอาจารย์ธรรมโชติ', 'http://159.192.129.43/sPb3/index.php/thammachotwebsite', 3, 545),
(5, 40, 'สหวิทยาเขตสามชุก', 'http://159.192.129.43/sPb3/index.php/samsukweb', 4, 545),
(5, 41, 'สหวิทยาเขตเมืองสามชุก', 'http://159.192.129.43/sPb3/index.php/samchukwebsite', 5, 545),
(5, 42, 'สหวิทยาเขตชาวดอย', 'http://159.192.129.43/sPb3/index.php/chawdoywebsite', 6, 545),
(5, 43, 'สหวิทยาเขตด่านช้าง', 'http://159.192.129.43/sPb3/index.php/danchangwebsite', 7, 545),
(5, 44, 'สหวิทยาเขตเขื่อนกระเสียว', 'http://159.192.129.43/sPb3/index.php/kheankraseawwebsite', 8, 545),
(5, 45, 'เว็บไซต์โรงเรียนในสหวิทยาเขตหนองหญ้าไซ', 'http://159.192.129.43/sPb3/index.php/nongyasaaiwebsite', 9, 545),
(5, 46, 'สหวิทยาเขตทัพหลวง-แจงงาม', 'http://159.192.129.43/sPb3/index.php/menuwebsites-spb3', 10, 545),
(6, 47, 'รายงานงบประมาณทั้งหมด', 'budget_guest.php', 1, 545),
(6, 48, 'รายการใบงวดทั้งหมด', 'period_guest.php', 2, 545);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu_bar_drop`
--
ALTER TABLE `menu_bar_drop`
  ADD PRIMARY KEY (`menu_bar_drop_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu_bar_drop`
--
ALTER TABLE `menu_bar_drop`
  MODIFY `menu_bar_drop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
